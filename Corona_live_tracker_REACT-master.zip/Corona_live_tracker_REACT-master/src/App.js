import React from 'react';
import Covid from './Components/covid.js';

function App() {
    return ( <
        >
        <
        Covid / >
        <
        />

    );
}

export default App;